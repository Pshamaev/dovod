@echo off
rem Задача MASKA_OCR_UPDATE, часть Б (16.11.2026). Запускается updater.apply_update
rem из mask/updater.py тремя аргументами: %1 - папка с распакованным обновлением,
rem %2 - папка программы (куда копировать), %3 - путь к Maska.exe (что перезапустить).
rem Ждёт закрытия Maska.exe (чтобы не копировать файлы поверх запущенного exe),
rem копирует новые файлы поверх старых и перезапускает программу.
setlocal
set SRC=%~1
set DEST=%~2
set EXE=%~3

:waitloop
tasklist /FI "IMAGENAME eq Maska.exe" 2>NUL | find /I "Maska.exe" >NUL
if "%ERRORLEVEL%"=="0" (
    timeout /t 1 /nobreak >NUL
    goto waitloop
)

xcopy "%SRC%\*" "%DEST%\" /E /Y /I >NUL
start "" "%EXE%"
endlocal
